package assignment;

import java.util.*;

public class mul_table {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int i = 1;
		while(i <= 10) {
			for(int j = 1; j <= 10; j++) {
				System.out.println(i+" * "+j+" = "+(i*j));
			}
			System.out.println("Want to see next table press (y/n)?");
			String c = s.next();
			if(c.equalsIgnoreCase("n")) {
				break;
			}
			i++;
		}
		System.out.println("You are out of the loop");
	}

}
