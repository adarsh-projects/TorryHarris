package assignment;

import java.util.*;

public class palindrom {
	public static boolean isPalindrom(String s) {
		int end = s.length()-1;
		int st = 0;
		while(st < end) {
			if(s.charAt(st) != s.charAt(end)) {
				return false;
			}
			st++;
			end--;
		}
		return true;
	} 
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		String input = s.next();
		if(isPalindrom(input)) {
			System.out.println(input+" is palindrom");
		}else{
			System.out.println(input+" is not palindrom");
		}
	}
}
