package assignment;

import java.util.*;

public class Number_Swap_without_temp {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter first Number: ");
		int a = s.nextInt();
		System.out.println("Enter first Number: ");
		int b = s.nextInt();
		
		//logic
		System.out.println("before Swapping: a = "+ a + " b = "+b);
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("after Swapping: a = "+ a + " b = "+b);
	}

}
