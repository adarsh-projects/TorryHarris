package assignment;

import java.util.*; 

public class armstrong_number {

	public static boolean isArmstrong(int num) {
		int ex = num;
		int res = 0;
		while(num > 0) {
			int temp = num%10;
			res = res + temp*temp*temp;
			num = num/10;
		}
		return ex == res;
	}
	// armstrong number are: 0, 1, 153, 370, 371,407
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		if(isArmstrong(n)) {
			System.out.println(n+" is Armstrong number");
		}else {
			System.out.println(n+" is not a Armstrong number");
		}
	}

}
