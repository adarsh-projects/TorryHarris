package assignment;

import java.util.Scanner;

public class Reverse_String_Number {
	public static String reverseString(String str) {
		StringBuilder sb = new StringBuilder("");
		int len = str.length();
		for(int i = len-1; i >= 0; i--) {
			sb.append(str.charAt(i) + "");
		}
		return sb.toString();
	}
	public static int reverseInteger(int num) {
		int res = 0;
		while(num > 0) {
			int temp = num%10;
			res = res * 10 + temp;
			num = num/10;
		}
		return res;
	} 
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("1. Reverse String \n2. Reverse Number");
		int n = s.nextInt();
		if(n == 1) {
			System.out.println("Enter String: ");
			String input = s.next();
			System.out.println(" Reverse of "+input+" is "+ reverseString(input)); 
		}else {
			System.out.println("Enter Number: ");
			int input = s.nextInt();
			System.out.println(" Reverse of "+input+" is "+ reverseInteger(input));			
		}
	}

}
