package assignment;

public class fibonacci_series {

	public static void main(String[] args) {
		int i = 0, a = 0, b = 1;
		System.out.println("Fibonacci serie: ");
		System.out.print("0 1 ");
		while(i < 10) {
			a = a+b;
			b = b+a;
			System.out.print(a+" "+b+" ");
			i++;
		}
		
	}

}
