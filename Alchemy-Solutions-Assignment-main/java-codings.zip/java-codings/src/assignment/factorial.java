package assignment;

import java.util.*;

public class factorial {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		long mul = 1;
		for(int i = 1; i <= n; i++) {
			mul = mul * i;
		}
		System.out.println("Factorial of "+ n +" is "+mul);
	}

}
