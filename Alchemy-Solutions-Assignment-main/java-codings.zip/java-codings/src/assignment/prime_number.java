package assignment;

import java.util.*;

public class prime_number {

	public static boolean isPrime(int num) {
		int sqrt_num = (int)Math.sqrt(num);
		
		//System.out.println(sqrt_num);
		for(int i = 2; i <= sqrt_num; i++) {
			if(num%i == 0) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();
		if(isPrime(num)) {
			System.out.println(num + " is prime number");
		}else{
			System.out.println(num + " is not prime number");
		}
	}

}
