package assignment;

import java.util.*;

public class even_number {
	static int test;
	public static void main(String[] args) {
		System.out.print(test);
		Scanner s = new Scanner(System.in);
		
		int n = s.nextInt();
		if(n%2 == 1) {
			System.out.println("This is Odd number");
		}else{
			System.out.println("This is Even number");
		}
	}

}
