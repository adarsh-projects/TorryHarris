package sorting;

import java.util.Arrays;

public class SelectionSort {

	public static void main(String[] args) {
		int [] arr = {716, 18, 142, 3, 18, 1, 9, 5, 2, 176, 4, 1};
		System.out.println("Before Sorting: " + Arrays.toString(arr));
		int n = arr.length;
		for(int i = 0; i < n; i++) {
			int index = -1, min = Integer.MAX_VALUE;
			
			for(int j = i; j < n; j++) {
				if(min > arr[j]) {
					min = arr[j];
					index = j;
				}
			}
			
			int temp = arr[i];
			arr[i] = arr[index];
			arr[index] = temp;
			
		}
		System.out.println("After Sorting:  " + Arrays.toString(arr));
	}

}
