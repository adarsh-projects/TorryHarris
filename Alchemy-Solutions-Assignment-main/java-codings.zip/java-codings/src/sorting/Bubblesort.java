package sorting;

import java.util.Arrays;

public class Bubblesort {

	public static void main(String[] args) {
		int [] arr = {716, 18, 142, 3, 18, 1, 9, 5, 2, 176, 4, 1};
		System.out.println("Before Sorting: " + Arrays.toString(arr));
		int n = arr.length;
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				if(arr[i] < arr[j]) {
					int temp = arr[j];
					arr[j] = arr[i];
					arr[i] = temp;
				}
			}
		}
		System.out.println("After Sorting:  " + Arrays.toString(arr));
	}

}
