package sorting;

import java.util.Arrays;

public class mergesort {
	public static void merge(int [] arr, int st, int end, int mid) {
		int left_size = mid-st+1, right_size = end-mid;
		int [] left_arr = new int[left_size];
		int [] right_arr = new int[right_size];
		int k = 0;
		
		for(int i = st; i < st+left_size; i++) {
			left_arr[k] = arr[i];
			k++;
		}
		k = 0;
		for(int i = mid; i < mid+right_size; i++) {
			right_arr[k] = arr[i+1];
			k++;
		}
		int i = 0, j = 0;
		k = st;
		while(left_size > i && right_size > j) {
			if(left_arr[i] < right_arr[j]) {
				arr[k] = left_arr[i];
				k++;
				i++;
			}else{
				arr[k] = right_arr[j];
				k++;
				j++;
			}
		}
		while(left_size > i) {
			arr[k] = left_arr[i];
			k++;
			i++;
		}
		
		while(right_size > j) {
			arr[k] = right_arr[j];
			k++;
			j++;
		}	
	}
	public static void mergeSort(int [] arr, int st, int ed) {
		if(st < ed) {
			int mid = st + (ed-st)/2;
			mergeSort(arr, st, mid);
			mergeSort(arr, mid+1, ed);
			merge(arr, st, ed, mid);
		}
	}
	public static void main(String[] args) {
		int [] arr = {716, 18, 142, 3, 18, 1, 9, 5, 2, 176, 4, 1};
		System.out.println("Before Sorting: " + Arrays.toString(arr));
		mergeSort(arr, 0, arr.length-1);
		System.out.println("After Sorting:  " + Arrays.toString(arr));
	}

}
