package elementsearch;

import java.util.Scanner;

public class binary_search {

	public static int binarySearch(int [] arr, int find, int st, int end) {
		if(st >= end) {
			return -1;
		}
		
		int mid = st + (end-st)/2;
		if(find == arr[mid]) {
			return mid;
		}else if(find < arr[mid]) {
			return binarySearch(arr, find, st, mid);
		}else {
			return binarySearch(arr, find, mid+1, end);
		}
	}
	public static void main(String[] args) {
		int [] arr = {10, 50, 60, 1345, 7456, 5436, 9878};
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int i = binarySearch(arr, n, 0, arr.length);
		if(i != -1) {
			System.out.println(n+" is found in array at "+i);
		}else {
			System.out.println(n+" is not found in array");
		}
	}

}
