package elementsearch;

import java.util.*;

public class linear_search {
	public static void main(String [] args) {
		int [] arr = {10, 50, 60, 1345, 7456, 5436, 9878};
		Scanner s = new Scanner(System.in);
		int i = 0,n = s.nextInt();
		for(i = 0; i < arr.length; i++) {
			if(arr[i] == n) {
				break;
			}
		}
		if(i < arr.length) {
			System.out.println(n+" is found in array at "+i);
		}else {
			System.out.println(n+" is not found in array");
		}
	}
}
