package practice;

class overloading{
	int add(int a, int b) {
		return a+b;
	}
	int add(int a, int b, int c) {
		return a+b+c;
	}
}
class overriding{
	void print() {
		System.out.println("hello i am in overriding class");
	}
}
public class polymorphism extends overriding{
	void print() {
		System.out.println("hello i am in polymorphism class");
	}
	public static void main(String[] args) {
		//overriding
		polymorphism p = new polymorphism();
		p.print();
		overloading o = new overloading();
		System.out.println("a+b: "+ o.add(5, 7));
		System.out.println("a+b+c: "+ o.add(5, 7, 6));
	}

}
