package practice;

import java.util.*;

public class admin{

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the cost of Adult: ");
		int number_of_adult = s.nextInt();
		System.out.print("Enter the cost of Child: ");
		int number_of_child = s.nextInt();
		PriceCost pc = new PriceCost();
		pc.setAdult_cost(number_of_adult);
		pc.setChild_cost(number_of_child);
		System.out.println("Value Updated Successfully");
	}

}
