package practice;

public class exceptiontext {
	public static boolean check(int num) {
		if(num == 1) {
			throw new StackOverflowError("Stack overflow exception!!");
		}
		return check(num+1);
	}
	public static void main(String[] args) throws Exception {
		int num1 = 9;
		int num2 = 0; 
		try {
			check(num2);
		}catch(Exception e1) {
			System.out.println("Message pad: "+e1);
		}
	}

}
