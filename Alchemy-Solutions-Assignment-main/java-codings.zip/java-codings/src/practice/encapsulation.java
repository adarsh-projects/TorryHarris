package practice;

import java.util.Scanner;

class PriceCal{
	PriceCost pc;
	
	int getAdultsCount(int number_of_adults){
		return new PriceCost().getAdult_cost() * number_of_adults;
	}
	int getChildCount(int number_of_adults){
		return new PriceCost().getChild_cost() * number_of_adults;
	}
}

class PrintDetails1 extends PriceCal{
	String from, to;
	int adultCost, childCost;
	int ac, cc;
	PrintDetails1(String from, String to, int ac, int cc){
		this.from = from;
		this.to = to;
		this.ac = ac;
		this.cc = cc;
		adultCost = new PriceCal().getAdultsCount(ac);
		childCost = new PriceCal().getChildCount(cc);
	}
	void printInfo(){
		System.out.println("\nTicket Information: ");
		System.out.println(from+"--------->"+to);
		System.out.println("Adults: "+ ac);
		System.out.println("Childs: "+ cc);
		System.out.println("Total Price: "+ (adultCost+childCost));
	}
}


public class encapsulation {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("From: ");
		String from = s.next();
		System.out.print("to: ");
		String to = s.next();
		System.out.print("Adult: ");
		int number_of_adult = s.nextInt();
		System.out.print("Child: ");
		int number_of_child = s.nextInt();
		PrintDetails1 pd = new PrintDetails1(from, to, number_of_adult, number_of_child);
		pd.printInfo();
	}

}
