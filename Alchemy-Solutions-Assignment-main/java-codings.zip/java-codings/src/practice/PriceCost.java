package practice;

public class PriceCost {

	private int adult_cost, child_cost;

	public int getAdult_cost() {
		return adult_cost;
	}

	public void setAdult_cost(int adult_cost) {
		this.adult_cost = adult_cost;
	}

	public int getChild_cost() {
		return child_cost;
	}

	public void setChild_cost(int child_cost) {
		this.child_cost = child_cost;
	}	
}
