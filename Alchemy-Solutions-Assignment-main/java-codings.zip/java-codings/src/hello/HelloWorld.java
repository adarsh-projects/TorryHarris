package hello;

import java.text.SimpleDateFormat;
import java.util.concurrent.ExecutorService;
import java.util.Date;
import java.util.concurrent.Executors;

class Task implements Runnable{
	private String name;
	public Task(String s) {
		name = s;
	}
	@Override
	public void run() {
		try {
			for(int i = 0; i <= 5; i++) {
				if(i == 0) {
					Date d = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
					System.out.println("Initialization Time for" + " task time -" + name + " = " + sdf.format(d));
				}else {
					Date d = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
					System.out.println("Executing Time for task time -" + name + " = " + sdf.format(d));
				}
				Thread.sleep(1000);
			}
			System.out.println(name+": Completed");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}

public class HelloWorld {
	static final int MAX_T = 3;
	public static void main(String [] args) {
		//creating 5 task
		// Task is a class
		Runnable r1 = new Task("task1");
		Runnable r2 = new Task("task2");
		Runnable r3 = new Task("task3");
		Runnable r4 = new Task("task4");
		Runnable r5 = new Task("task5");
		
		//create a thread pool with MAX_T no. of
		//thread as the fixed pool size
		ExecutorService es = Executors.newFixedThreadPool(MAX_T);
		
		es.execute(r1);
		es.execute(r2);
		es.execute(r3);
		es.execute(r4);
		es.execute(r5);
		
		es.shutdown();
		
	}
}
