package hello;

import java.util.*;

public class generics {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("John");
		al.add("Rohit");
		al.add("Sumit");
		
		Iterator i = al.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
