package hello;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListObj {
	String name, address;
	int age;
	ArrayListObj(String name, String address, int marks){
		this.name= name;
		this.address = address;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public int getAge() {
		return age;
	}
	public static void main(String[] args) {
		ArrayList<ArrayListObj> al = new ArrayList<ArrayListObj>();
		for(int i = 0; i <= 2; i++) {
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Name: ");
			String name = s.nextLine();
			
			System.out.println("EnterAddress: ");
			String address = s.nextLine();
			
			System.out.println("Enter Age: ");
			int age = s.nextInt();
			
			al.add(new ArrayListObj(name, address, age));
		}
		System.out.println(al);
		System.out.println(al.get(0));
		System.out.println(al.get(1));
		System.out.println(al.get(2));
	}
	@Override
	public String toString() {
		return "ArrayListObj [name=" + name + ", address=" + address + ", age=" + age + "]";
	}


}
