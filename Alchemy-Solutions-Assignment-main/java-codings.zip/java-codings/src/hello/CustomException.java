package hello;
//
//class InvalidUserException extends Exception{
//	InvalidUserException(String mssg){
//		super(mssg);
//	}
//}

public class CustomException {
//	static void validateUser(String username, String password) throws InvalidUserException {
//		if(username.equals("admin") && password.equals("admin123")) {
//			System.out.println("User is Valid");
//		}else {
//			throw new InvalidUserException("Invalid User");
//		}
//	}
	public static void main(String[] args) throws InterruptedException{
		Thread.sleep(10000);
		System.out.println("hello world");
//		validateUser("admin", "admin123");
	}

}
