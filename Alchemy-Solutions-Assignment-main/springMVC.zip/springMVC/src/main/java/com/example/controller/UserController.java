package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.User;
import com.example.DAO.UserDAO;

@Controller
public class UserController {
	
	@Autowired
	UserDAO userdao;
	
	@RequestMapping("/userform")
	public String showForm(Model model) {
		model.addAttribute("command", new User());
		return "userform";
	}
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String save(@ModelAttribute("user")User user) {
		userdao.addData(user);
		return "redirect:/viewuser";
	}
	@RequestMapping("/viewuser")
	public String viewuser(Model model) {
		List<User> userlist = userdao.getUser();
		model.addAttribute("command", userlist);
		return "viewuser";
	}
	
	@RequestMapping("/edituser/{usernamr}")
	public String edit(@PathVariable String username, Model model) {
		User user = userdao.getUserByUserName(username);
		model.addAttribute("command", user);
		return "usereditform";
	}
	
	@RequestMapping(value="/editsave", method=RequestMethod.POST)	
	public String editsave(@ModelAttribute("user")User user) {
		userdao.updateData(user);
		return "redirect:/viewuser";
	}
	
	@RequestMapping(value="/deleteuser", method=RequestMethod.GET)
	public String delete(@PathVariable String username) {
		userdao.deleteData(username);
		return "redirect:/viewuser";
	}
	
}
