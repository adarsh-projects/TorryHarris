package com.example.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.example.User;

public class UserDAO {
	private JdbcTemplate jdbctemp;

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
	
	public int addData(User u) {
		String query = "insert into user values('"+u.getUsername()+"','"+u.getPassword()+"')";
		return jdbctemp.update(query);
	}
	
	public int updateData(User u) {
		String query = "update user set usernamr='" + u.getUsername()+"', password='"+u.getPassword()+"' where usernamr='"+u.getUsername()+"';";
		return jdbctemp.update(query);
	}
	
	public int deleteData(String username) {
		String query = "delete from passanger where name = "+username;
		return jdbctemp.update(query);
	}
	
	@SuppressWarnings("deprecation")
	public User getUserByUserName(String usernamr) {
		String query = "select * from user usernamr='?'";
		return jdbctemp.queryForObject(query, new Object[] {usernamr}, new BeanPropertyRowMapper<User>(User.class));
	}
	
	public List<User> getUser() {
		String qur = "select * from user;";
		return jdbctemp.query(qur, new RowMapper<User>() {
			public User mapRow(ResultSet rs, int row) throws SQLException {
				User user = new User();
				user.setUsername(rs.getString(1));
				user.setPassword(rs.getString(2));
				return user;
			}
		});
	}
	
}
