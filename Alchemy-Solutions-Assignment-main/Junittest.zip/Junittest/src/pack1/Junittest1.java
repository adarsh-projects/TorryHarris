package pack1;

class Calculation{
	public static int addition(int a,int b) {
		return a+b;
	}
}
public class Junittest1 extends Calculation{
	public static void main(String args[]) {
//		Calculation.addition(12, 23);
	}
}
